package com.sbi.project.layer2;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Component
@Entity
@Table(name="project_payee")
public class Payee {
	
	

	@Id
	@GeneratedValue
	@Column(name="payee_id")
	private int payeeId;
	
	@Column(name="payee_name")
	private String payeeName;
	
	@Column(name="payee_account_number")
	private long payeeAccountNumber;

	@Column(name="payee_nickname")
	private String nickName;
	
	@ManyToOne
	@JoinColumn(name="account_number")
	private Account account;// = new Account();

	public int getPayeeId() {
		return payeeId;
	}

	public void setPayeeId(int payeeId) {
		this.payeeId = payeeId;
	}

	public String getPayeeName() {
		return payeeName;
	}

	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}

	public long getPayeeAccountNumber() {
		return payeeAccountNumber;
	}

	public void setPayeeAccountNumber(long payeeAccountNumber) {
		this.payeeAccountNumber = payeeAccountNumber;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	@JsonIgnore
	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}
//	
//	@Override
//	public String toString() {
//		return "Payee [payeeId=" + payeeId + ", payeeName=" + payeeName + ", payeeAccountNumber=" + payeeAccountNumber
//				+ ", nickName=" + nickName + ", account=" + account + "]";
//	}
// 
	
	
}
