package com.sbi.project.layer3;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.sbi.project.layer2.Account;

@Repository
public class AccountRepoImpl extends BaseRepoImpl implements AccountRepository {

	@Transactional
	public Account getAccount(int accountNumber) {
		System.out.println("getAccountService()");
		System.out.println(super.find(Account.class,accountNumber));
		return super.find(Account.class,accountNumber);
		 
	}

	@Transactional
	public void setAccount(Account account) {
		super.merge(account);
	}

}
