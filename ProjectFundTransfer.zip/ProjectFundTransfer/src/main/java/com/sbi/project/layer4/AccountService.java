package com.sbi.project.layer4;

import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Account;

@Service
public interface AccountService {

	Account getAccountService(int accountNumber);
	void setAccountService(Account account);
	
}
