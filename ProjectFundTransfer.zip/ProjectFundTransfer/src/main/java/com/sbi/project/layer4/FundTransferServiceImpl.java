package com.sbi.project.layer4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Account;

@Service
public class FundTransferServiceImpl implements FundTransferService{

	Account creditAccount;
	Account debitAccount;
	@Autowired
	AccountService accServ;
	
	public void transferFund(int dAcc, int cAcc, int amount) {
		
		creditAccount = accServ.getAccountService(cAcc);
		debitAccount = accServ.getAccountService(dAcc);
		
		creditAccount.setBalance(creditAccount.getBalance()+amount);
		debitAccount.setBalance(debitAccount.getBalance()-amount);
		
		accServ.setAccountService(creditAccount);
		accServ.setAccountService(debitAccount);
		
	}
}
