package com.sbi.project.layer5;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.project.layer2.Account;
import com.sbi.project.layer4.AccountService;

@CrossOrigin
@RestController
@RequestMapping("/account")
public class AccountController {
	
	@Autowired
	AccountService  accServ;
	@RequestMapping("/get/{accNum}")
	public Account getAccountDetails(@PathVariable ("accNum") int accountNumber) {
		System.out.println("getAccountController");
		return accServ.getAccountService(accountNumber);
	}
	
	@PostMapping("/setAccount")
	public void updateBalance(@RequestBody Account account) {
		accServ.setAccountService(account);
	}
}

