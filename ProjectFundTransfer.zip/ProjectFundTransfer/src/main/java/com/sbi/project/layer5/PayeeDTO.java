package com.sbi.project.layer5;

import com.sbi.project.layer2.Payee;

public class PayeeDTO {

	public int targetAccountNumber;
	public Payee payeeToAdd= new Payee();
	
}
