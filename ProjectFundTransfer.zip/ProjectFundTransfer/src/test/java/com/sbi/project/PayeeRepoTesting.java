package com.sbi.project;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.project.layer2.Account;
import com.sbi.project.layer2.Payee;
import com.sbi.project.layer3.AccountRepository;
import com.sbi.project.layer3.PayeeRepository;
import com.sbi.project.layer4.AccountService;

@SpringBootTest
public class PayeeRepoTesting {
	
	@Autowired
	PayeeRepository payeeRepo;
	@Autowired
	AccountRepository accRepo;
	@Autowired
	AccountService accSer;
	@Test
	public void payeeLoadingRepotest(){
		List<Payee> payeeList=payeeRepo.findAllPayee(10001);
		for (Payee payee : payeeList) {
			payee.getPayeeName();
		}
		
	}
	@Test
	public void getAccount() {
		Account account=accRepo.getAccount(10003);
		System.out.println(account.getAccountHolderName());
	}
	
	@Test
	public void getAccountService() {
		Account account=accSer.getAccountService(10003);
		System.out.println(account.getAccountHolderName());
	}

}
