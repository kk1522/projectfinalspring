import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { HomeComponent } from './home/home.component';
import { HomepageComponent } from './homepage/homepage.component';
import { LoginComponent } from './login/login.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { PayeeMenuComponent } from './payee-menu/payee-menu.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  {
    path: 'home', component: HomeComponent},
      { path: 'fundtransfer', component: FundtransferComponent },
      { path: 'payee', component: PayeeMenuComponent },
      {path:'homepage', component:HomepageComponent},
      { path: '',   redirectTo: '/homepage', pathMatch: 'full' }, // redirect to `first-component`
      { path: '**', component: PagenotfoundComponent },
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
