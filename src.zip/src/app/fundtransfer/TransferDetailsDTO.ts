export class TransferDetailsDTO{
    debitAccount:number=0;
    creditAccount:number=0;
    amount:number=0;
}