import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FundtransferserviceService } from '../fundtransferservice.service';
import { Account } from '../payee-menu/Account';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  username:any="";
  balance:any="";
  useraccount:any="";
  showbalance:boolean=false;
  selfAccount:Account=new Account();
  constructor(private router:Router,private fundSer:FundtransferserviceService) { 
    this.username=sessionStorage.getItem('name');
    this.balance=sessionStorage.getItem('balance');
    this.useraccount=sessionStorage.getItem('user');
    this.getAccountDetailsUser();
  }
  ngOnInit(): void {
    
  }
  toggleBal(){
    this.getAccountDetailsUser();
    this.showbalance=!this.showbalance;
    this.balance=sessionStorage.getItem('balance');
  }
  logout(){
    sessionStorage.clear();
    this.router.navigateByUrl('/login')
  }
  getAccountDetailsUser(){
    this.fundSer.getAccountService(Number(this.useraccount)).subscribe(
      (data:Account)=>{
        this.selfAccount=data;
      }
    );
    sessionStorage.setItem('balance',String(this.selfAccount.balance));
  }

}
