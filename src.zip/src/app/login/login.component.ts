import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FundtransferserviceService } from '../fundtransferservice.service';
import { Account } from '../payee-menu/Account';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user:string="";
  username:number=0;
  sessionOn:boolean=false;
  password:string="";
  userAccount:Account=new Account();
  userValidate:boolean=false;
  loginMsg:string="";

  constructor(private fServ:FundtransferserviceService,private router:Router) {
    if(sessionStorage.getItem('name')!=null){
      this.sessionOn=true;
    }
   }

  

  getAccountDetails(){
    this.username=Number(this.user);
    // console.log("inside get account details"+this.username);
     this.fServ.getAccountService(this.username).subscribe(
       (data:Account)=>{
         this.userAccount = data;
         console.log("inside subscribe "+this.userAccount.accountNumber);
       }
     );
     console.log("inside getAccountDetails "+this.userAccount.accountNumber);
     
   }
  validateUser(){
    //console.log("inside validate user"+this.user);
    this.username=Number(this.user);
    //this.getAccountDetails();
    
        //console.log("after this.getAccountDetails"+this.username);
        console.log("after this.getAccountDetails"+this.userAccount.accountNumber);
        if(this.username===this.userAccount.accountNumber&&this.password===this.userAccount.password){
          sessionStorage.setItem('user',String(this.username));
          sessionStorage.setItem('name',this.userAccount.accountHolderName);
          sessionStorage.setItem('sessionOn',"1");
          sessionStorage.setItem('balance',String(this.userAccount.balance));
          this.router.navigateByUrl('/homepage');
          console.log("inside if "+this.userAccount.accountNumber);
          console.log(sessionStorage.getItem('name'));
          this.loginMsg="";
        }
        else{
            alert("Invalid User Credentials");
            this.user="";
            this.password="";
            //alert(this.loginMsg);
        }
       

  }

  ngOnInit(): void {
    
  }

  

}
